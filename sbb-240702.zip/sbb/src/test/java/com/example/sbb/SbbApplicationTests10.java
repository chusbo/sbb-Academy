package com.example.sbb;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.sbb.answer.Answer;
import com.example.sbb.answer.AnswerRepository;

@SpringBootTest
public class SbbApplicationTests10 {
	
	@Autowired
	AnswerRepository answerRepository;
	
	@Test
	void testJpa() {
		
	Optional<Answer> oa = this.answerRepository.findById(1);
	assertTrue(oa.isPresent());
	Answer a = oa.get();
	assertEquals(2, a.getQuestion().getId());
	}
}
