//package com.example.sbb;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import java.util.List;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.example.sbb.question.Question;
//import com.example.sbb.question.QuestionRepository;
//
//@SpringBootTest
//public class SbbApplicationTests2 {
//
//	@Autowired
//	private QuestionRepository questionRepository;
//		
//	@Test
//	void testJpa() {
//		List<Question> all = this.questionRepository.findAll();
//		assertEquals(2, all.size());
//		
//		Question q = all.get(1); //()해당 인데스 값으로 검색
//		assertEquals("content2", q.getContent()); //해당 컬러명,값으로 검색
//	}
//}
////assertEquals(기댓값, 실젯값)
////예상한 결과와 실제 결과가 동일한지를 확인하는 목적으로 사용함
