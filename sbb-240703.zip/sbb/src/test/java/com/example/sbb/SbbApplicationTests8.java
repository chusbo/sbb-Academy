//package com.example.sbb;
//
//import static org.junit.jupiter.api.Assertions.assertTrue;
//
//import java.util.Optional;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.example.sbb.question.Question;
//import com.example.sbb.question.QuestionRepository;
//
//@SpringBootTest
//class SbbApplicationTests8 {
//
//	@Autowired
//	private QuestionRepository questionRepository;
//	
//	@Test
//	void testJpa() {
//		Optional<Question> oq = this.questionRepository.findById(1);
//		// assertTrue(참조변수명.isPresent()); 수정 전 변수가 비어있지 않고 값을 가지고 있는지 확인(값을 포함하고 있는지 여부 확인)
//		assertTrue(oq.isPresent()); 
//		Question q = oq.get();
//		q.setSubject("수정된 제목");
//		this.questionRepository.save(q);
//	}
//}
